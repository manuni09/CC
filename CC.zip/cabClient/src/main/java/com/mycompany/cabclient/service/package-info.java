
/**
 * Restful services here
 */
package com.mycompany.cabclient.service;