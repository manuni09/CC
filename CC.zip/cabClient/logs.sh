#!/bin/sh
docker logs cabClient -f