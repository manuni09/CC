
/**
 * Restful services here
 */
package com.mycompany.cabservice.service;