/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cabservice.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Manuni
 */
@Entity
@Table(name = "cabtb")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cabtb.findAll", query = "SELECT c FROM Cabtb c"),
    @NamedQuery(name = "Cabtb.findByCabid", query = "SELECT c FROM Cabtb c WHERE c.cabid = :cabid"),
    @NamedQuery(name = "Cabtb.findByModel", query = "SELECT c FROM Cabtb c WHERE c.model = :model"),
    @NamedQuery(name = "Cabtb.findByStatus", query = "SELECT c FROM Cabtb c WHERE c.status = :status"),
    @NamedQuery(name = "Cabtb.findByCompany", query = "SELECT c FROM Cabtb c WHERE c.company = :company"),
    @NamedQuery(name = "Cabtb.findByDrivername", query = "SELECT c FROM Cabtb c WHERE c.drivername = :drivername"),
    @NamedQuery(name = "Cabtb.findByRating", query = "SELECT c FROM Cabtb c WHERE c.rating = :rating"),
    @NamedQuery(name = "Cabtb.findBySize", query = "SELECT c FROM Cabtb c WHERE c.size = :size")})
public class Cabtb implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "cabid")
    private Integer cabid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "model")
    private String model;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "status")
    private String status;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "company")
    private String company;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "drivername")
    private String drivername;
    @Basic(optional = false)
    @NotNull
    @Column(name = "rating")
    private int rating;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "size")
    private String size;

    public Cabtb() {
    }

    public Cabtb(Integer cabid) {
        this.cabid = cabid;
    }

    public Cabtb(Integer cabid, String model, String status, String company, String drivername, int rating, String size) {
        this.cabid = cabid;
        this.model = model;
        this.status = status;
        this.company = company;
        this.drivername = drivername;
        this.rating = rating;
        this.size = size;
    }

    public Integer getCabid() {
        return cabid;
    }

    public void setCabid(Integer cabid) {
        this.cabid = cabid;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        this.drivername = drivername;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cabid != null ? cabid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cabtb)) {
            return false;
        }
        Cabtb other = (Cabtb) object;
        if ((this.cabid == null && other.cabid != null) || (this.cabid != null && !this.cabid.equals(other.cabid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.cabservice.entity.Cabtb[ cabid=" + cabid + " ]";
    }
    
}
