/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cabservice.model;

import com.mycompany.cabservice.entity.Cabtb;
import java.util.ArrayList;
import java.util.Collection;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;

/**
 *
 * @author Manuni
 */
public class cabmodel {
    EntityManager em;

    public cabmodel() {
        em = Persistence.createEntityManagerFactory("cabPU").createEntityManager();
    }
    
    public Collection<Cabtb> getCabs()
    {
        return em.createNamedQuery("Cabtb.findAll").getResultList();
    }
    
    public Collection<Cabtb> getSize(String size)
    {
        Collection<Cabtb> allcabs = new ArrayList<Cabtb>();
        System.out.println("M :"+size);
        if(size.equals("mini"))
        {
            System.out.println("Mini :"+size);
         allcabs = em.createQuery("SELECT c FROM Cabtb c WHERE c.size ='mini' ").getResultList();
        }
        
        if(size.equals("normal"))
        {
         allcabs = em.createQuery("SELECT c FROM Cabtb c WHERE c.size ='normal' ").getResultList();
        }
        return allcabs;
    }
}
