package com.mycompany.cabservice.service;

import com.mycompany.cabservice.entity.Cabtb;
import com.mycompany.cabservice.model.cabmodel;
import java.util.Collection;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/example")
public class ExampleService {

    @Inject cabmodel cm;
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Cabtb> getAllCabs()
    {
        return cm.getCabs();
    }
    
    @GET
    @Path("getSize/{size}")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Cabtb> getSize(@PathParam("size") String size)
    {
        return cm.getSize(size);
    }

}
