#!/bin/sh
docker logs cabService -f