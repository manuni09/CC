#!/bin/sh
mvn clean package
docker build -t manuni/cabService .
