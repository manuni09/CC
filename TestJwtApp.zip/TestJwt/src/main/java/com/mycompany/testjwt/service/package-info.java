
/**
 * Restful services here
 */
package com.mycompany.testjwt.service;